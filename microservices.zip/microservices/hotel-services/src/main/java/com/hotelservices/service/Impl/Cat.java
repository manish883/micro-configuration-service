package com.hotelservices.service.Impl;

import org.springframework.stereotype.Service;

import com.hotelservices.repository.Animal;

@Service
public class Cat implements Animal{

	@Override
	public String chat() {
		return "meow";
		
	}

	
}
