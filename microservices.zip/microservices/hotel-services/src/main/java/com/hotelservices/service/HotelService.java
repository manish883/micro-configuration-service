package com.hotelservices.service;

import java.util.List;

import com.hotelservices.entity.Hotel;

public interface HotelService {

	Hotel create(Hotel hotel);
	Hotel getHotel(String id);
	List<Hotel> getAllHotel();
}
