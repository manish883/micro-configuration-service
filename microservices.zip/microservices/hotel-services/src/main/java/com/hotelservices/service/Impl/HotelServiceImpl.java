package com.hotelservices.service.Impl;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotelservices.entity.Hotel;
import com.hotelservices.exception.ResourceNotFoundException;
import com.hotelservices.repository.HotelRepo;
import com.hotelservices.service.HotelService;

@Service
public class HotelServiceImpl implements HotelService{

	@Autowired
	private HotelRepo hotelRepo;
	
	@Override
	public Hotel create(Hotel hotel) {
		
		String randomUserId = UUID.randomUUID().toString();
		// user.setUserId(randomUserId);
		hotel.setId(randomUserId);
		return hotelRepo.save(hotel);
	}

	@Override
	public Hotel getHotel(String id) {
		// TODO Auto-generated method stub
		return hotelRepo.findById(id).orElseThrow(()->new ResourceNotFoundException("Hotel with the given id not found !"));
	}

	@Override
	public List<Hotel> getAllHotel() {
		// TODO Auto-generated method stub
		return hotelRepo.findAll();
	}

}
