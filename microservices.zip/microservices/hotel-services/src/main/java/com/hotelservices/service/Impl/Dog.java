package com.hotelservices.service.Impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.hotelservices.repository.Animal;
@Primary
@Service
public class Dog implements Animal{

	@Override
	public String chat() {
		// TODO Auto-generated method stub
		return "bark";
	}

}
