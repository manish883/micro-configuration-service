package com.userservices.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.userservices.entity.User;
import com.userservices.services.UserServicce;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import io.github.resilience4j.retry.annotation.Retry;

@RestController
@RequestMapping("/users")
public class UserController {

	@Autowired
	private UserServicce userService;

	@PostMapping
	public ResponseEntity<User> createUser(@RequestBody User user) {
		User user1 = userService.saveUser(user);
		return ResponseEntity.status(HttpStatus.CREATED).body(user1);
	}

	@GetMapping("/{userID}")
	// @CircuitBreaker(name = "ratingHotelBreaker", fallbackMethod =
	// "ratingHotelFallback")
	// @Retry(name = "ratingHotelService", fallbackMethod = "ratingHotelFallback")
	@RateLimiter(name = "userRateLimiter", fallbackMethod = "ratingHotelFallback")
	public ResponseEntity<User> getSingleUser(@PathVariable("userID") String userID) {
		User user1 = userService.getUser(userID);
		return ResponseEntity.ok(user1);
	}

	int retryCount = 1;

	// creating fall back method for circuitbreaker
	public ResponseEntity<User> ratingHotelFallback(String userId, Exception ex) {
		System.out.println(" Retry Count  :: " + retryCount);
		retryCount++;
		User user = User.builder().email("@email.com").name("dummyname").about("some services down").userId("156132")
				.build();
		return new ResponseEntity<>(user, HttpStatus.OK);
	}

	@GetMapping("")
	public ResponseEntity<List<User>> getAllUser() {
		List<User> user1 = userService.getAllUser();
		return ResponseEntity.ok(user1);
	}
}
