package com.userservices.services.Impl;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.userservices.entity.Hotel;
import com.userservices.entity.Rating;
import com.userservices.entity.User;
import com.userservices.external.HotelService;
import com.userservices.repository.UserRepository;
import com.userservices.services.UserServicce;

@Service
public class UserServiceImpl implements UserServicce {

	@Autowired
	private UserRepository userRepo;
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private HotelService hotelServices;
	

	@Override
	public User saveUser(User user) {

		String randomUserId = UUID.randomUUID().toString();
		user.setUserId(randomUserId);
		return userRepo.save(user);
	}

	@Override
	public List<User> getAllUser() {
		return userRepo.findAll();
	}

	@Override
	public User getUser(String userId) {
		User user = userRepo.findById(userId).orElseThrow();
		Rating[] ratingOfUser = restTemplate.getForObject("http://RATING-SERVICE/ratings/users/" + userId,
				Rating[].class);
		
		List<Rating> ratings = Arrays.stream(ratingOfUser).toList();
		List<Rating> ratingList = ratings.stream().map(rating -> {
			
			Hotel hotel = hotelServices.getHotel(rating.getHotelId());
			rating.setHotel(hotel);
			return rating;
		}).collect(Collectors.toList());

		user.setRatings(ratingList);
		return user;
	}

}
