package com.userservices.services;

import java.util.List;

import com.userservices.entity.User;

public interface UserServicce {

	User saveUser(User user);
	List<User> getAllUser();
	User getUser(String userId);
}
