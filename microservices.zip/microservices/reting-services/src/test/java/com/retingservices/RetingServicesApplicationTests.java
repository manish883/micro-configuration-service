package com.retingservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetingServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
